Experimental Environment:   tensorflow-gpu==1.14.0 keras==2.2.5 numpy==1.19.5 python==3.6.13 scikit-learn=0.22.2
