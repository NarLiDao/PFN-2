import numpy as np
import os
from sklearn.preprocessing import LabelEncoder, MinMaxScaler


class LoadData(object):
    
    # Three files are needed in the path
    def __init__(self, path, dataset, loss_type, train_num, valid_num, test_num):
        self.file1 = train_num
        self.file2 = valid_num
        self.file3 = test_num
        # self.dataset = dataset
        self.file_all = ['train.libsvm', 'valid.libsvm', 'test.libsvm']
        self.file_dataset = ['frappe', 'movielens']
        self.path = path + dataset + "/" 
        self.trainfile = self.path + "train.libsvm"  
        self.testfile = self.path + "test.libsvm"  
        self.validationfile = self.path + "valid.libsvm"  
        self.features_M = self.map_features()  
        self.Train_data, self.Validation_data, self.Test_data = self.construct_data(loss_type) 

    def map_features(self):  
        self.features = {}
        self.read_features(self.trainfile)
        self.read_features(self.testfile)
        self.read_features(self.validationfile)
        return len(self.features)  


    def read_features(self, file):  
        
        f_rf = file.split('/')
        if self.file_dataset[0] == f_rf[2] or self.file_dataset[1] == f_rf[2]:
            f = open(file)
            line = f.readline()  
            i = len(self.features) 
            while line: 
                items = line.strip().split(' ')
                for item in items[1:]:
                    if item not in self.features:
                        self.features[item] = i
                        
                        i = i + 1
                line = f.readline()  
            f.close()
        else:
            f = open(file)
            line_tr = f.readlines()  
            if self.file_all[0] == f_rf[3]:
                line = line_tr[:self.file1]
                for line_item in line:
                    # line_tr = f.readline().strip()  
                    i = len(self.features) 
                    items = line_item.strip().split(' ')
                    for item in items[1:]:
                        if item not in self.features:
                            self.features[item] = i
                           
                            i = i + 1
                        # line_tr = f.readline()  
                f.close()

            elif self.file_all[1] == f_rf[3]:
                line = line_tr[:self.file2]
                for line_item in line:
                    i = len(self.features)  
                    items = line_item.strip().split(' ')
                    for item in items[1:]:
                        if item not in self.features:
                            self.features[item] = i
                            
                            i = i + 1
                    # line_v = f.readline()  
                f.close()
            elif self.file_all[2] == f_rf[3]:
                line = line_tr[:self.file2]
                for line_item in line:
                    # for j in range(self.file3):
                    #    line_te = f.readline().strip() 
                    i = len(self.features)  
                    # while line_te:  
                    items = line_item.strip().split(' ')
                    for item in items[1:]:
                        if item not in self.features:
                            self.features[item] = i
                            # print('当前经过for循环的self.features:',self.features)
                            i = i + 1
                # line_te = f.readline()  
                f.close()

    def construct_data(self, loss_type):

        X_, Y_, Y_for_logloss = self.read_data(self.trainfile)
        if loss_type == 'logloss' or loss_type == 'auc':
            Train_data = self.construct_dataset(X_, Y_for_logloss)
        else:
            Train_data = self.construct_dataset(X_, Y_)

        X_, Y_, Y_for_logloss = self.read_data(self.validationfile)
        if loss_type == 'logloss' or loss_type == 'auc':
            Validation_data = self.construct_dataset(X_, Y_for_logloss)
        else:
            Validation_data = self.construct_dataset(X_, Y_)

        X_, Y_, Y_for_logloss = self.read_data(self.testfile)
        if loss_type == 'logloss' or loss_type == 'auc':
            Test_data = self.construct_dataset(X_, Y_for_logloss)
        else:
            Test_data = self.construct_dataset(X_, Y_)
        # print("# of test:", len(Y_))

        return Train_data, Validation_data, Test_data


    def read_data(self, file):

        
        f_rd = file.split('/')
        X_ = []
        Y_ = []
        Y_for_logloss = []
        # line:'-1.0 84982:1 58:1 39525:1\n'
        if self.file_dataset[0] == f_rd[2] or self.file_dataset[1] == f_rd[2]:
            f = open(file)
            line = f.readline()  
            while line:
                
                items = line.strip().split(' ')
                Y_.append(1.0 * float(items[0]))
               
                X_.append([self.features[item] for item in items[1:]])
                line = f.readline()  
            f.close()  
            return X_, Y_, Y_for_logloss
        else:
            f = open(file)
            line_tr = f.readlines()  
            if self.file_all[0] == f_rd[3]:
                line = line_tr[:self.file1]
                for line_item in line:
                    items = line_item.strip().split(' ')
                    Y_.append(1.0 * float(items[0]))
                    Y_for_logloss.append(1.0 * float(items[0]))

                    X_.append([self.features[item] for item in items[1:]])

                f.close()
                
                return X_, Y_, Y_for_logloss
            elif self.file_all[1] == f_rd[3]:
                line = line_tr[:self.file2]
                for line_item in line:
                    items = line_item.strip().split(' ')
                    Y_for_logloss.append(1.0 * float(items[0]))
                    X_.append([self.features[item] for item in items[1:]])

                f.close()  
                return X_, Y_, Y_for_logloss
            elif self.file_all[2] == f_rd[3]:
                line = line_tr[:self.file3]
                for line_item in line:
                    items = line_item.strip().split(' ')
                    Y_.append(1.0 * float(items[0]))

                    Y_for_logloss.append(1.0 * float(items[0]))
                    X_.append([self.features[item] for item in items[1:]])
                f.close()
               
                return X_, Y_, Y_for_logloss

    def construct_dataset(self, X_, Y_):
        Data_Dic = {}  
        
        X_lens = [len(line) for line in X_]
        
        indexs = np.argsort(X_lens)
        Data_Dic['Y'] = [Y_[i] for i in indexs]
        Data_Dic['X'] = [X_[i] for i in indexs]
        return Data_Dic

    def truncate_features(self):
        
        num_variable = len(self.Train_data['X'][0])
     
        for i in range(len(self.Train_data['X'])):
            num_variable = min([num_variable, len(self.Train_data['X'][i])])
        for i in range(len(self.Train_data['X'])):
            self.Train_data['X'][i] = self.Train_data['X'][i][0:num_variable]
        for i in range(len(self.Validation_data['X'])):
            self.Validation_data['X'][i] = self.Validation_data['X'][i][0:num_variable]
        for i in range(len(self.Test_data['X'])):
            self.Test_data['X'][i] = self.Test_data['X'][i][0:num_variable]
        return num_variable


if __name__ == '__main__':
    pass
